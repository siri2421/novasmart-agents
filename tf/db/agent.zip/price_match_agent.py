import os
import logging
from google.adk.agents import Agent
from google.adk.models import Gemini

PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT")
GEMINI_LOCATION = os.environ.get("GOOGLE_CLOUD_REGION", "us-central1")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

# Removed logging configuration for stdout compatibility

# =========================================================================
# 1. Dynamic A2A Escalation Tool for Agent 1
# =========================================================================

async def escalate_to_strategy_agent(sku: str, requested_price: float) -> str:
    """
    Escalate a high-discount price match request to the back-office Markdown Strategy Agent (Agent 2)
    via direct HTTP A2A streaming.
    
    Args:
        sku: The product SKU (e.g., 'SKU-HSE-4455')
        requested_price: The competitor's price being requested for match
        
    Returns:
        The markdown strategy evaluation and approval decision.
    """
    import uuid
    import json
    import httpx
    import google.auth
    from google.auth.transport.requests import Request
    from google.adk.integrations.agent_registry import AgentRegistry
    
    print(f"[A2A Escalation] Escalating SKU {sku} with requested price ${requested_price}...")
    
    # 1. Resolve the Strategy Agent's endpoint from the Registry (with environment URN fallback for testing)
    try:
        registry = AgentRegistry(project_id=PROJECT_ID, location=GEMINI_LOCATION)
        agent_info = registry.get_agent_info("services/markdown-strategy-agent")
        url = agent_info["agentSpec"]["content"]["url"]
        print(f"[A2A Escalation] Resolved Strategy Agent URL: {url}")
    except Exception as e:
        print(f"[A2A Escalation] Registry lookup failed: {e}. Checking STRATEGY_AGENT_URN environment variable...")
        strategy_agent_urn = os.environ.get("STRATEGY_AGENT_URN")
        if not strategy_agent_urn:
            return f"Error: Failed to resolve Markdown Strategy Agent in Agent Registry: {e}"
        url = f"https://{GEMINI_LOCATION}-aiplatform.googleapis.com/v1beta1/{strategy_agent_urn}/a2a"
        print(f"[A2A Escalation] Resolved Strategy Agent URL from env fallback: {url}")
        
    # 2. Retrieve active credentials token
    try:
        creds, _ = google.auth.default()
        auth_request = Request()
        creds.refresh(auth_request)
        token = creds.token
    except Exception as e:
        print(f"❌ Failed to retrieve Google credentials: {e}")
        return f"Error: Failed to authenticate for A2A escalation: {e}"
        
    # 3. Build HTTP headers & inject OTel trace context for propagation!
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    try:
        from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
        TraceContextTextMapPropagator().inject(headers)
        print("[A2A Escalation] OpenTelemetry trace context injected successfully.")
    except Exception as e:
        print(f"[A2A Escalation] Failed to inject OTel trace context: {e}")
        
    # 4. Construct A2A request payload
    prompt = (
        f"Escalation Request: SKU '{sku}' has a requested price of ${requested_price:.2f}. "
        f"Please query inventory and cost tables in BigQuery to approve or deny this override."
    )
    payload = {
        "request": {
            "messageId": str(uuid.uuid4()),
            "role": "ROLE_USER",
            "content": [{"text": prompt}]
        }
    }
    
    # 5. Execute direct HTTP streaming call
    stream_url = f"{url}/v1/message:stream"
    final_reply = None
    json_buffer = ""
    
    try:
        async with httpx.AsyncClient() as client:
            async with client.stream("POST", stream_url, json=payload, headers=headers, timeout=60.0) as response:
                if response.status_code != 200:
                    await response.aread()
                    raise Exception(f"HTTP {response.status_code}: {response.text}")
                    
                async for line in response.aiter_lines():
                    if not line:
                        continue
                    if line.startswith("data:"):
                        line_content = line[5:].strip()
                        if not line_content:
                            continue
                        json_buffer += line_content
                        try:
                            event_data = json.loads(json_buffer)
                            json_buffer = ""
                            
                            # Extract the text reply from the artifact update
                            artifact_update = event_data.get("artifactUpdate", {})
                            if artifact_update:
                                parts = artifact_update.get("artifact", {}).get("parts", [])
                                if parts and "text" in parts[0]:
                                    final_reply = parts[0]["text"]
                        except json.JSONDecodeError:
                            continue
    except Exception as e:
        print(f"❌ Direct A2A call failed: {e}")
        return f"Error during A2A escalation to Markdown Strategy Agent: {e}"
        
    if not final_reply:
        return "Error: Markdown Strategy Agent completed execution but returned no response."
        
    return final_reply

# =========================================================================
# 2. Agent Definition: Price Match Verification Agent
# =========================================================================

_VERIFICATION_INSTRUCTION = """
You are the Front-line Price Match Verification Agent (price_match_agent) for NovaSmart. Your job is to verify competitor price match requests submitted by store associates.

**Operating Principles:**

1. **Intake & Calculate Discount**: When an associate requests a price match, you will be provided with:
   - The product SKU (e.g. SKU-HSE-4455)
   - The original shelf price (e.g. $450.00)
   - The competitor's advertised price (e.g. $350.00)
   
   First, calculate the discount percentage:
   discount_percentage = (shelf_price - competitor_price) / shelf_price

2. **Direct Approval Cap (<= 20% Discount)**:
   - **If the discount is less than or equal to 20%**: You are fully authorized to approve this match directly.
   - Return a clear, friendly response stating:
     - The price match is **APPROVED** directly.
     - Specify the discount percentage calculated.
     - State that the discount is within your 20% front-line approval cap.
     - Return the final price.
     
3. **Escalation Cap (> 20% Discount)**:
   - **If the discount is greater than 20%**: You are NOT authorized to approve this price match directly.
   - You **MUST** escalate the request to the back-office Markdown Strategy Agent (Agent 2) by calling the `escalate_to_strategy_agent` tool!
   - Pass the SKU and the requested competitor price to the tool.
   - Relay the Markdown Strategy Agent's response exactly and transparently to the user. Do not summarize or alter its decision. If the strategy agent approves it, confirm the match is approved. If the strategy agent denies it, confirm it is denied and state the reasons.
"""

import asyncio
from google.genai import Client

class LoopBoundGemini(Gemini):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._clients = {}

    @property
    def api_client(self):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
            
        if loop is None:
            return super().api_client
            
        if loop not in self._clients:
            print(f"🔄 [LoopBoundGemini] Creating new GenAI Client for event loop {id(loop)}...")
            self._clients[loop] = Client(vertexai=True, project=PROJECT_ID, location=GEMINI_LOCATION)
        return self._clients[loop]

    @api_client.setter
    def api_client(self, value):
        # Ignore manual overrides to prevent breaking OpenTelemetry HTTP context
        pass

price_match_agent = Agent(
    name="price_match_agent",
    model=LoopBoundGemini(
        model=GEMINI_MODEL,
    ),
    instruction=_VERIFICATION_INSTRUCTION,
    tools=[escalate_to_strategy_agent],
)

from google.adk.apps import App
from google.adk.artifacts.in_memory_artifact_service import InMemoryArtifactService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService
from vertexai.agent_engines.templates.adk import AdkApp

# 1. Wrap the Agent in the standard ADK App
adk_app = App(
    root_agent=price_match_agent,
    name="price_match_agent",
)

# 2. Expose the standard ADK AdkApp template for Vertex AI Agent Engine deployment (enables streamQuery & Model Armor ingress!)
agent_engine = AdkApp(
    app=adk_app,
    artifact_service_builder=InMemoryArtifactService,
    memory_service_builder=InMemoryMemoryService,
)
